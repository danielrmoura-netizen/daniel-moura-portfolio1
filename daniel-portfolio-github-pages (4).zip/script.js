const root = document.documentElement;
const themeButton = document.querySelector('.theme-toggle');
const themeIcon = document.querySelector('.theme-icon');
const savedTheme = localStorage.getItem('portfolio-theme');
const systemLight = window.matchMedia('(prefers-color-scheme: light)').matches;

function applyTheme(theme) {
  root.dataset.theme = theme;
  themeIcon.textContent = theme === 'light' ? '☾' : '☼';
  themeButton.setAttribute('aria-label', theme === 'light' ? 'Ativar modo escuro' : 'Ativar modo claro');
  themeButton.title = theme === 'light' ? 'Ativar modo escuro' : 'Ativar modo claro';
}
applyTheme(savedTheme || (systemLight ? 'light' : 'dark'));
themeButton.addEventListener('click', () => {
  const nextTheme = root.dataset.theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('portfolio-theme', nextTheme);
  applyTheme(nextTheme);
});

const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-links');
menuToggle.addEventListener('click', () => {
  const isOpen = navMenu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Fechar menu' : 'Abrir menu');
});
document.querySelectorAll('.nav-links a').forEach(link => link.addEventListener('click', () => {
  navMenu.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Abrir menu');
}));

// Camada de interação visual criada sem dependências externas.
const progress = document.createElement('div');
progress.className = 'scroll-progress';
document.body.prepend(progress);
const glow = document.createElement('div');
glow.className = 'cursor-glow';
document.body.append(glow);
window.addEventListener('pointermove', event => {
  root.style.setProperty('--mouse-x', `${event.clientX}px`);
  root.style.setProperty('--mouse-y', `${event.clientY}px`);
  glow.style.left = `${event.clientX}px`;
  glow.style.top = `${event.clientY}px`;
});
function updateScrollUI() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0}%`;
  document.querySelector('.site-header').classList.toggle('scrolled', window.scrollY > 18);
}
window.addEventListener('scroll', updateScrollUI, { passive: true });
updateScrollUI();

document.getElementById('year').textContent = new Date().getFullYear();
const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(element => revealObserver.observe(element));

// Destaca a seção atual na navegação durante a rolagem.
const navigationLinks = [...document.querySelectorAll('.nav-links > a')];
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
navigationLinks.forEach(link => {
  const target = link.getAttribute('href');
  link.classList.toggle('active', target === currentPage || (currentPage === '' && target === 'index.html'));
});
const sections = navigationLinks.map(link => document.querySelector(link.getAttribute('href'))).filter(Boolean);
if (sections.length) {
  const sectionObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) navigationLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`));
    });
  }, { rootMargin: '-35% 0px -55% 0px' });
  sections.forEach(section => sectionObserver.observe(section));
}

// Inclinação muito sutil nos cards: desativada em telas touch.
if (window.matchMedia('(pointer:fine)').matches) {
  document.querySelectorAll('.project-card, .highlight-card').forEach(card => {
    card.addEventListener('pointermove', event => {
      const rect = card.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width - .5) * 4;
      const y = ((event.clientY - rect.top) / rect.height - .5) * -4;
      card.style.transform = `perspective(700px) rotateX(${y}deg) rotateY(${x}deg) translateY(-5px)`;
    });
    card.addEventListener('pointerleave', () => { card.style.transform = ''; });
  });
}

const projects = {
  api: { kicker: '01 / API REST', title: 'Atividade API', description: 'Uma aplicação focada em demonstrar o fluxo completo entre uma interface web e uma fonte de dados externa, com feedback claro para cada estado da requisição.', architecture: 'Front-end estático + camada assíncrona de consumo REST.', objective: 'Buscar, interpretar e renderizar dados dinamicamente sem recarregar a página.', stack: 'HTML5 · CSS3 · JavaScript · Fetch API', repo: 'https://github.com/danielrmoura-netizen/atividadeapi' },
  motor: { kicker: '02 / PIXEL-PERFECT', title: 'Figma Motor', description: 'Uma tradução cuidadosa de um protótipo de design para uma interface web consistente, preservando hierarquia, ritmo visual e comportamento responsivo.', architecture: 'Componentes semânticos + CSS responsivo orientado ao layout.', objective: 'Conectar a intenção do design à experiência real no navegador.', stack: 'HTML5 · CSS3 · JavaScript · Figma to Code', repo: 'https://github.com/danielrmoura-netizen/figmamotor2' },
  football: { kicker: '03 / LANDING PAGE', title: 'Futebol Page', description: 'Uma landing page temática que combina identidade esportiva, organização de conteúdo e navegação direta para criar uma experiência envolvente.', architecture: 'Página única responsiva com seções modulares e navegação por âncoras.', objective: 'Apresentar conteúdo esportivo com clareza em desktop e mobile.', stack: 'HTML5 · CSS3 · Responsive Design', repo: 'https://github.com/danielrmoura-netizen/futebolpage' }
};
const modal = document.getElementById('project-modal');
document.querySelectorAll('.details-button').forEach(button => button.addEventListener('click', () => {
  const project = projects[button.dataset.project];
  document.getElementById('modal-kicker').textContent = project.kicker;
  document.getElementById('modal-title').textContent = project.title;
  document.getElementById('modal-description').textContent = project.description;
  document.getElementById('modal-architecture').textContent = project.architecture;
  document.getElementById('modal-objective').textContent = project.objective;
  document.getElementById('modal-stack').textContent = project.stack;
  document.getElementById('modal-repo').href = project.repo;
  modal.showModal();
}));
document.querySelector('.modal-close').addEventListener('click', () => modal.close());
modal.addEventListener('click', event => { if (event.target === modal) modal.close(); });

const form = document.getElementById('contact-form');
if (form) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const status = form.querySelector('.form-status');
    if (!form.checkValidity()) {
      form.reportValidity();
      status.textContent = 'Confira os campos obrigatórios.';
      status.style.color = '#f87171';
      return;
    }
    status.textContent = 'Mensagem preparada! Configure seu serviço de envio para receber contatos.';
    status.style.color = 'var(--green)';
    form.reset();
  });
}
